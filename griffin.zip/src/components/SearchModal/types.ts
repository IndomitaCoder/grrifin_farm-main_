export enum CurrencyModalView {
  search,
  manage,
  importToken,
  importList,
}

export enum CommonBasesType {
  LIQUIDITY = 'LIQUIDITY',
  SWAP_LIMITORDER = 'SWAP_LIMITORDER',
}

export default CurrencyModalView
