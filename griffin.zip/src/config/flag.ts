export const FLAG_FARM: 'old' | 'pkg' | 'api' = 'pkg'
