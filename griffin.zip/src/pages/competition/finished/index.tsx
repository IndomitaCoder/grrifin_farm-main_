import FinishedCompetitions from '../../../views/TradingCompetition/FinishedCompetitions'

export default FinishedCompetitions
