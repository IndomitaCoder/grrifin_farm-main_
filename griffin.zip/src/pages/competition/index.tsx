import TradingCompetition from '../../views/TradingCompetition'

export default TradingCompetition
