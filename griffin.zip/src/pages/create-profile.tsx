import ProfileCreation from '../views/ProfileCreation'

export default ProfileCreation
