import FarmAuction from '../../views/FarmAuction'

export default FarmAuction
