import LimitOrders from '../views/LimitOrders'

const LimitOrdersPage = () => {
  return <LimitOrders />
}

export default LimitOrdersPage
