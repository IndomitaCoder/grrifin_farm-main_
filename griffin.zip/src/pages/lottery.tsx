import Lottery from '../views/Lottery'

export default Lottery
