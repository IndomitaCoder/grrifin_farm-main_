import Migration from '../views/Migration'

export default Migration
