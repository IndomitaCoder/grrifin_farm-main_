import Activity from 'views/Nft/market/Activity'

const ActivityPage = () => {
  return <Activity />
}

export default ActivityPage
