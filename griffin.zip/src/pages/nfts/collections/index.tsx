import Collections from '../../../views/Nft/market/Collections'

const CollectionsPage = () => {
  return <Collections />
}

export default CollectionsPage
