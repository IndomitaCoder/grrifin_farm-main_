import PancakeSquad from '../views/PancakeSquad'

export default PancakeSquad
