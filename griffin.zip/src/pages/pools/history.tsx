import Pools from 'views/Pools'

export default Pools
