import Pottery from '../views/Pottery'

export default Pottery
