import PredictionConfigProviders from '../../views/Predictions/context/PredictionConfigProviders'
import Predictions from '../../views/Predictions'

export default function Prediction() {
  return <Predictions />
}

Prediction.Layout = PredictionConfigProviders
