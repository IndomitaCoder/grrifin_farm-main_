import Voting from '../../views/Voting'

export default Voting
