import CreateProposal from '../../../views/Voting/CreateProposal'

export default CreateProposal
